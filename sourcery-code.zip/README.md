# Fortnite-Music-Changer
# YOU MUST BE IN WINDOWED FULLSCREEN FOR THIS TO WORK
## Also if you're going to distribute please put this git repo *next to* your download link, ty.
Allows you to play music based on where you are in the game - At the title screen, Main Menu and at victory

It isn't programmed very well, but it works (I used this to learn c#)

This could allow you to add the old music back.

How does it work?

It gets 2-3 set pixels on the screen, tests their color against what it should be for that menu, and if they match - it will play it.
