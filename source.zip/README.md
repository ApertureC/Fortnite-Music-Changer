# Fortnite-Music-Changer
Allows you to play music based on where you are in the game - At the title screen, Main Menu and at victory

# ABANDONED PLEASE READ BELOW (May come back if modifying pak files is fixed)
## Thanks to /u/PATXS for helping me push the final release
## There's so much I wanted to do but FNBRLeaks got in the way
1. FNBRLeaks claiming he made it (Didn't include license and shoved "Developed by @FNBRLeaks" on it, got loads more downloads.)
2. Epic games has added it back
3. Cleaner methods made by better programmers with decent code

# What I wanted to do:
* Make the code not look like a disaster (really not worth the effort anymore)

# What you can do:
* Pull requests if you want to add anything, I doubt this will be a thing anymore since the traffic is slowly dying off, if you open a pull request tell me on reddit /u/ApertureCoder


It isn't programmed very well, but it works (I used this to learn c#)

This could allow you to add the old music back.

How does it work?

It gets 2-3 set pixels on the screen, tests their color against what it should be for that menu, and if they match - it will play it.
